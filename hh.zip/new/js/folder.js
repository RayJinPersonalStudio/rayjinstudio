function isZhLanguage() {
    return (navigator.language || navigator.browserLanguage).indexOf("zh-CN") > -1
}

function getFolderIconsData(e) {
    var t = getParameters("folderId", window.location.href);
    if (!t) return null;
    for (var a = e.data, i = null, o = 0, n = a.length; o < n; o++) {
        var r = a[o];
        if (r.id === t) {
            i = r;
            break
        }
    }
    return i ? {
        title: i.name,
        data: i.items.filter(function(e) {
            return !/^infinity:\/\//.test(e.url)
        })
    } : null
}

function getNewData() {
    var e = window.location.href,
        t = "",
        a = getParameters("uid", e),
        i = getParameters("secret", e),
        o = getParameters("mobileId", e);
    t = "";
    o ? t = "https://infinity-api.infinitynewtab.com/c/" + o : a && i && (t = "https://infinity-api.infinitynewtab.com/c/0?uid=" + a + "&secret=" + i), t && $.get(t, function(e, t, a) {
        if ("success" == t && 200 === e.status) {
            var i = e.backupTime,
                o = getStorage("defaultData");
            if (!o || o.backupTime !== i) {
                var n = getFolderIconsData(e);
                n && dellWithShowIconData(n), setStorage("defaultData", e)
            }
        }
    })
}

function initData() {
    var e = getStorage("defaultData"),
        t = null;
    e && (t = getFolderIconsData(e)), t && dellWithShowIconData(t), getNewData()
}

function getParameters(e, t) {
    t || (t = location.href);
    var a = "[\\?&]" + (e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]")) + "=([^&#]*)",
        i = new RegExp(a).exec(t);
    return null == i ? null : i[1]
}

function dellWithShowIconData(e) {
    $("#folder-title").text(e.title);
    for (var t = "", a = 0, i = (e = e.data).length; a < i;) {
        var o = e[a].url,
            n = e[a].name,
            r = e[a].src;
        if (r) t += '<li><a href="' + o + '"target="_self"><div class="icon-img-box"><img src="' + r + '"></div><p class="overflow-ellips">' + n + "</p></a></li>";
        else {
            t += '<li><a href="' + o + '"target="_self"><div class="icon-img-box" style="background:' + e[a].bgColor + ';" >' + n + '</div><p class="overflow-ellips">' + n + "</p></a></li>"
        }
        a++
    }
    t += '<li id="fakeitem"></li>', document.getElementById("list-item").innerHTML = t, calcateIconLayOut(i)
}

function calcateIconLayOut(e) {
    var t = elementResizeDetectorMaker(),
        a = (elementResizeDetectorMaker({
            strategy: "scroll"
        }), e);
    void 0;
    var i = document.getElementById("ul-box"),
        o = document.getElementById("list-item"),
        n = document.getElementById("fakeitem");
    void 0;
    (document.body.clientWidth / 100).toFixed(2);
    void 0, layloutReset(a, o, n, !1), t.listenTo(i, function(e) {
        layloutReset(a, o, n, !1)
    })
}

function layloutReset(e, t, a, i) {
    var o = t.offsetWidth,
        n = document.body.clientWidth / 100 * 2.4.toFixed(3),
        r = 45+ 2 * n;
    void 0;
    var l = Math.floor(o / r);
    void 0;
    var c = ((o - l * r) / (l - 1)).toFixed(3);
    void 0;
    var s = e % l;
    if (void 0, s > 0) {
        var d = l - s;
        void 0;
        var g = (d * r + (d - 1) * c).toFixed(2);
        void 0, a.style.cssText = "display:block;visibility: hidden;height: 0;padding:0;margin:0;width:" + g + "px;"
    } else void 0, a.style.cssText = "display:none;"
}

function isSuportLocalStorage() {
    return !!window.localStorage
}

function setStorage(e, t) {
    var a = Object.prototype.toString.call(t);
    "[object Array]" !== a && "[object Object]" !== a || (t = JSON.stringify(t)), localStorage.setItem(e, t), !localStorage[t] && t.length < 50 && Cookies.set(e, t, {
        expires: 37
    })
}

function getStorage(e) {
    try {
        var t = localStorage.getItem(e);
        return t ? JSON.parse(t) : Cookies.get(e)
    } catch (e) {
        return t
    }
}
var i18n = {
    get: function(e) {
        return isZhLanguage() ? this[e].zh : this[e].en
    }
};
try {
    initData()
} catch (e) {
    console(e)
}
var browser = {
    versions: function() {
        var e = navigator.userAgent;
        navigator.appVersion;
        return {
            trident: e.indexOf("Trident") > -1,
            presto: e.indexOf("Presto") > -1,
            webKit: e.indexOf("AppleWebKit") > -1,
            gecko: e.indexOf("Gecko") > -1 && -1 == e.indexOf("KHTML"),
            mobile: !!e.match(/AppleWebKit.*Mobile.*/),
            ios: !!e.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
            android: e.indexOf("Android") > -1 || e.indexOf("Adr") > -1,
            iPhone: e.indexOf("iPhone") > -1,
            iPad: e.indexOf("iPad") > -1,
            webApp: -1 == e.indexOf("Safari"),
            weixin: e.indexOf("MicroMessenger") > -1,
            qq: null !== e.match(/\sQQ/i),
            Safari: e.indexOf("Safari") > -1 && e.indexOf("Chrome") < 1 && e.indexOf("Version") > -1
        }
    }(),
    language: (navigator.browserLanguage || navigator.language).toLowerCase()
};
$(function() {
    browser.versions.mobile && FastClick.attach(document.body)
});
