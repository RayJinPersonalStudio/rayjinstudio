! function(e) {
    if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
    else if ("function" == typeof define && define.amd) define([], e);
    else {
        ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).elementResizeDetectorMaker = e()
    }
}(function() {
    return function e(t, n, i) {
        function o(a, s) {
            if (!n[a]) {
                if (!t[a]) {
                    var l = "function" == typeof require && require;
                    if (!s && l) return l(a, !0);
                    if (r) return r(a, !0);
                    var d = new Error("Cannot find module '" + a + "'");
                    throw d.code = "MODULE_NOT_FOUND", d
                }
                var c = n[a] = {
                    exports: {}
                };
                t[a][0].call(c.exports, function(e) {
                    var n = t[a][1][e];
                    return o(n || e)
                }, c, c.exports, e, t, n, i)
            }
            return n[a].exports
        }
        for (var r = "function" == typeof require && require, a = 0; a < i.length; a++) o(i[a]);
        return o
    }({
        1: [function(e, t, n) {
            "use strict";

            function i() {
                var e = {},
                    t = 0,
                    n = 0,
                    i = 0;
                return {
                    add: function(o, r) {
                        r || (r = o, o = 0), o > n ? n = o : o < i && (i = o), e[o] || (e[o] = []), e[o].push(r), t++
                    },
                    process: function() {
                        for (var t = i; t <= n; t++)
                            for (var o = e[t], r = 0; r < o.length; r++)(0, o[r])()
                    },
                    size: function() {
                        return t
                    }
                }
            }
            var o = e("./utils");
            t.exports = function(e) {
                function t() {
                    for (c = !0; d.size();) {
                        var e = d;
                        d = i(), e.process()
                    }
                    c = !1
                }

                function n() {
                    l = function(e) {
                        return function(e) {
                            return setTimeout(e, 0)
                        }(e)
                    }(t)
                }
                var r = (e = e || {}).reporter,
                    a = o.getOption(e, "async", !0),
                    s = o.getOption(e, "auto", !0);
                s && !a && (r && r.warn("Invalid options combination. auto=true and async=false is invalid. Setting async=true."), a = !0);
                var l, d = i(),
                    c = !1;
                return {
                    add: function(e, t) {
                        !c && s && a && 0 === d.size() && n(), d.add(e, t)
                    },
                    force: function(e) {
                        c || (void 0 === e && (e = a), l && (function(e) {
                            clearTimeout(e)
                        }(l), l = null), e ? n() : t())
                    }
                }
            }
        }, {
            "./utils": 2
        }],
        2: [function(e, t, n) {
            "use strict";
            (t.exports = {}).getOption = function(e, t, n) {
                var i = e[t];
                return void 0 !== i && null !== i || void 0 === n ? i : n
            }
        }, {}],
        3: [function(e, t, n) {
            "use strict";
            var i = t.exports = {};
            i.isIE = function(e) {
                if (! function() {
                        var e = navigator.userAgent.toLowerCase();
                        return -1 !== e.indexOf("msie") || -1 !== e.indexOf("trident") || -1 !== e.indexOf(" edge/")
                    }()) return !1;
                if (!e) return !0;
                return e === function() {
                    var e = 3,
                        t = document.createElement("div"),
                        n = t.getElementsByTagName("i");
                    do {
                        t.innerHTML = "\x3c!--[if gt IE " + ++e + "]><i></i><![endif]--\x3e"
                    } while (n[0]);
                    return e > 4 ? e : void 0
                }()
            }, i.isLegacyOpera = function() {
                return !!window.opera
            }
        }, {}],
        4: [function(e, t, n) {
            "use strict";
            (t.exports = {}).forEach = function(e, t) {
                for (var n = 0; n < e.length; n++) {
                    var i = t(e[n]);
                    if (i) return i
                }
            }
        }, {}],
        5: [function(e, t, n) {
            "use strict";
            var i = e("../browser-detector");
            t.exports = function(e) {
                function t(e) {
                    return r(e).object
                }
                var n = (e = e || {}).reporter,
                    o = e.batchProcessor,
                    r = e.stateHandler.getState;
                if (!n) throw new Error("Missing required dependency: reporter.");
                return {
                    makeDetectable: function(e, t, a) {
                        a || (a = t, t = e, e = null), e = e || {}, i.isIE(8) ? a(t) : function(e, t) {
                            function a() {
                                function o() {
                                    if ("static" === d.position) {
                                        e.style.position = "relative";
                                        var t = function(e, t, n, i) {
                                            var o = n[i];
                                            "auto" !== o && "0" !== function(e) {
                                                return e.replace(/[^-\d\.]/g, "")
                                            }(o) && (e.warn("An element that is positioned static has style." + i + "=" + o + " which is ignored due to the static positioning. The element will need to be positioned relative, so the style." + i + " will be set to 0. Element: ", t), t.style[i] = 0)
                                        };
                                        t(n, e, d, "top"), t(n, e, d, "right"), t(n, e, d, "bottom"), t(n, e, d, "left")
                                    }
                                }
                                "" !== d.position && (o(), l = !0);
                                var a = document.createElement("object");
                                a.style.cssText = s, a.tabIndex = -1, a.type = "text/html", a.onload = function() {
                                    function n(e, t) {
                                        e.contentDocument ? t(e.contentDocument) : setTimeout(function() {
                                            n(e, t)
                                        }, 100)
                                    }
                                    l || o(), n(this, function(n) {
                                        t(e)
                                    })
                                }, i.isIE() || (a.data = "about:blank"), e.appendChild(a), r(e).object = a, i.isIE() && (a.data = "about:blank")
                            }
                            var s = "display: block; position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none; padding: 0; margin: 0; opacity: 0; z-index: -1000; pointer-events: none;",
                                l = !1,
                                d = window.getComputedStyle(e),
                                c = e.offsetWidth,
                                u = e.offsetHeight;
                            r(e).startSize = {
                                width: c,
                                height: u
                            }, o ? o.add(a) : a()
                        }(t, a)
                    },
                    addListener: function(e, n) {
                        function o() {
                            n(e)
                        }
                        if (!t(e)) throw new Error("Element is not detectable by this strategy.");
                        i.isIE(8) ? (r(e).object = {
                            proxy: o
                        }, e.attachEvent("onresize", o)) : t(e).contentDocument.defaultView.addEventListener("resize", o)
                    },
                    uninstall: function(e) {
                        i.isIE(8) ? e.detachEvent("onresize", r(e).object.proxy) : e.removeChild(t(e)), delete r(e).object
                    }
                }
            }
        }, {
            "../browser-detector": 3
        }],
        6: [function(e, t, n) {
            "use strict";
            var i = e("../collection-utils").forEach;
            t.exports = function(e) {
                function t(e, t, n) {
                    if (e.addEventListener) e.addEventListener(t, n);
                    else {
                        if (!e.attachEvent) return a.error("[scroll] Don't know how to add event listeners.");
                        e.attachEvent("on" + t, n)
                    }
                }

                function n(e, t, n) {
                    if (e.removeEventListener) e.removeEventListener(t, n);
                    else {
                        if (!e.detachEvent) return a.error("[scroll] Don't know how to remove event listeners.");
                        e.detachEvent("on" + t, n)
                    }
                }

                function o(e) {
                    return l(e).container.childNodes[0].childNodes[0].childNodes[0]
                }

                function r(e) {
                    return l(e).container.childNodes[0].childNodes[0].childNodes[1]
                }
                var a = (e = e || {}).reporter,
                    s = e.batchProcessor,
                    l = e.stateHandler.getState,
                    d = (e.stateHandler.hasState, e.idHandler);
                if (!s) throw new Error("Missing required dependency: batchProcessor");
                if (!a) throw new Error("Missing required dependency: reporter.");
                var c = function() {
                        var e = document.createElement("div");
                        e.style.cssText = "position: absolute; width: 1000px; height: 1000px; visibility: hidden; margin: 0; padding: 0;";
                        var t = document.createElement("div");
                        t.style.cssText = "position: absolute; width: 500px; height: 500px; overflow: scroll; visibility: none; top: -1500px; left: -1500px; visibility: hidden; margin: 0; padding: 0;", t.appendChild(e), document.body.insertBefore(t, document.body.firstChild);
                        var n = 500 - t.clientWidth,
                            i = 500 - t.clientHeight;
                        return document.body.removeChild(t), {
                            width: n,
                            height: i
                        }
                    }(),
                    u = "erd_scroll_detection_container";
                return function(e, t) {
                    if (!document.getElementById(e)) {
                        var n = t + "_animation",
                            i = "/* Created by the element-resize-detector library. */\n";
                        i += "." + t + " > div::-webkit-scrollbar { display: none; }\n\n", i += "." + t + "_animation_active { -webkit-animation-duration: 0.1s; animation-duration: 0.1s; -webkit-animation-name: " + n + "; animation-name: " + n + "; }\n", i += "@-webkit-keyframes " + n + " { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }\n",
                            function(t, n) {
                                n = n || function(e) {
                                    document.head.appendChild(e)
                                };
                                var i = document.createElement("style");
                                i.innerHTML = t, i.id = e, n(i)
                            }(i += "@keyframes " + n + " { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }")
                    }
                }("erd_scroll_detection_scrollbar_style", u), {
                    makeDetectable: function(e, n, f) {
                        function h() {
                            if (e.debug) {
                                var t = Array.prototype.slice.call(arguments);
                                if (t.unshift(d.get(n), "Scroll: "), a.log.apply) a.log.apply(null, t);
                                else
                                    for (var i = 0; i < t.length; i++) a.log(t[i])
                            }
                        }

                        function g(e) {
                            var t = l(e).container.childNodes[0],
                                n = getComputedStyle(t);
                            return !n.width || -1 === n.width.indexOf("px")
                        }

                        function p() {
                            var e = getComputedStyle(n),
                                t = {};
                            return t.position = e.position, t.width = n.offsetWidth, t.height = n.offsetHeight, t.top = e.top, t.right = e.right, t.bottom = e.bottom, t.left = e.left, t.widthCSS = e.width, t.heightCSS = e.height, t
                        }

                        function v() {
                            if (h("storeStyle invoked."), l(n)) {
                                var e = p();
                                l(n).style = e
                            } else h("Aborting because element has been uninstalled")
                        }

                        function m(e, t, n) {
                            l(e).lastWidth = t, l(e).lastHeight = n
                        }

                        function b() {
                            return 2 * c.width + 1
                        }

                        function y() {
                            return 2 * c.height + 1
                        }

                        function w(e) {
                            return e + 10 + b()
                        }

                        function x(e) {
                            return e + 10 + y()
                        }

                        function E(e, t, n) {
                            var i = o(e),
                                a = r(e),
                                s = w(t),
                                l = x(n),
                                d = function(e) {
                                    return 2 * e + b()
                                }(t),
                                c = function(e) {
                                    return 2 * e + y()
                                }(n);
                            i.scrollLeft = s, i.scrollTop = l, a.scrollLeft = d, a.scrollTop = c
                        }

                        function S() {
                            var e = l(n).container;
                            if (!e) {
                                (e = document.createElement("div")).className = u, e.style.cssText = "visibility: hidden; display: inline; width: 0px; height: 0px; z-index: -1; overflow: hidden; margin: 0; padding: 0;", l(n).container = e,
                                    function(e) {
                                        e.className += " " + u + "_animation_active"
                                    }(e), n.appendChild(e);
                                var i = function() {
                                    l(n).onRendered && l(n).onRendered()
                                };
                                t(e, "animationstart", i), l(n).onAnimationStart = i
                            }
                            return e
                        }

                        function z() {
                            function e() {
                                l(n).onExpand && l(n).onExpand()
                            }

                            function i() {
                                l(n).onShrink && l(n).onShrink()
                            }
                            if (h("Injecting elements"), l(n)) {
                                ! function() {
                                    var e = l(n).style;
                                    if ("static" === e.position) {
                                        n.style.position = "relative";
                                        var t = function(e, t, n, i) {
                                            var o = n[i];
                                            "auto" !== o && "0" !== function(e) {
                                                return e.replace(/[^-\d\.]/g, "")
                                            }(o) && (e.warn("An element that is positioned static has style." + i + "=" + o + " which is ignored due to the static positioning. The element will need to be positioned relative, so the style." + i + " will be set to 0. Element: ", t), t.style[i] = 0)
                                        };
                                        t(a, n, e, "top"), t(a, n, e, "right"), t(a, n, e, "bottom"), t(a, n, e, "left")
                                    }
                                }();
                                var o = l(n).container;
                                o || (o = S());
                                var r = c.width,
                                    s = c.height,
                                    d = "position: absolute; flex: none; overflow: hidden; z-index: -1; visibility: hidden; " + function(e, t, n, i) {
                                        return e = e ? e + "px" : "0", t = t ? t + "px" : "0", n = n ? n + "px" : "0", i = i ? i + "px" : "0", "left: " + e + "; top: " + t + "; right: " + i + "; bottom: " + n + ";"
                                    }(-(1 + r), -(1 + s), -s, -r),
                                    f = document.createElement("div"),
                                    g = document.createElement("div"),
                                    p = document.createElement("div"),
                                    v = document.createElement("div"),
                                    m = document.createElement("div"),
                                    b = document.createElement("div");
                                f.dir = "ltr", f.style.cssText = "position: absolute; flex: none; overflow: hidden; z-index: -1; visibility: hidden; width: 100%; height: 100%; left: 0px; top: 0px;", f.className = u, g.className = u, g.style.cssText = d, p.style.cssText = "position: absolute; flex: none; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;", v.style.cssText = "position: absolute; left: 0; top: 0;", m.style.cssText = "position: absolute; flex: none; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;", b.style.cssText = "position: absolute; width: 200%; height: 200%;", p.appendChild(v), m.appendChild(b), g.appendChild(p), g.appendChild(m), f.appendChild(g), o.appendChild(f), t(p, "scroll", e), t(m, "scroll", i), l(n).onExpandScroll = e, l(n).onShrinkScroll = i
                            } else h("Aborting because element has been uninstalled")
                        }

                        function A() {
                            function t(e, t, n) {
                                var i = function(e) {
                                        return o(e).childNodes[0]
                                    }(e),
                                    r = w(t),
                                    a = x(n);
                                i.style.width = r + "px", i.style.height = a + "px"
                            }

                            function c(i) {
                                var o = n.offsetWidth,
                                    r = n.offsetHeight;
                                h("Storing current size", o, r), m(n, o, r), s.add(0, function() {
                                    if (l(n))
                                        if (u()) {
                                            if (e.debug) {
                                                var i = n.offsetWidth,
                                                    s = n.offsetHeight;
                                                i === o && s === r || a.warn(d.get(n), "Scroll: Size changed before updating detector elements.")
                                            }
                                            t(n, o, r)
                                        } else h("Aborting because element container has not been initialized");
                                    else h("Aborting because element has been uninstalled")
                                }), s.add(1, function() {
                                    l(n) ? u() ? E(n, o, r) : h("Aborting because element container has not been initialized") : h("Aborting because element has been uninstalled")
                                }), i && s.add(2, function() {
                                    l(n) ? u() ? i() : h("Aborting because element container has not been initialized") : h("Aborting because element has been uninstalled")
                                })
                            }

                            function u() {
                                return !!l(n).container
                            }

                            function f() {
                                h("notifyListenersIfNeeded invoked");
                                var e = l(n);
                                return void 0 === l(n).lastNotifiedWidth && e.lastWidth === e.startSize.width && e.lastHeight === e.startSize.height ? h("Not notifying: Size is the same as the start size, and there has been no notification yet.") : e.lastWidth === e.lastNotifiedWidth && e.lastHeight === e.lastNotifiedHeight ? h("Not notifying: Size already notified") : (h("Current size not notified, notifying..."), e.lastNotifiedWidth = e.lastWidth, e.lastNotifiedHeight = e.lastHeight, void i(l(n).listeners, function(e) {
                                    e(n)
                                }))
                            }

                            function p() {
                                if (h("Scroll detected."), g(n)) h("Scroll event fired while unrendered. Ignoring...");
                                else {
                                    var e = n.offsetWidth,
                                        t = n.offsetHeight;
                                    e !== n.lastWidth || t !== n.lastHeight ? (h("Element size changed."), c(f)) : h("Element size has not changed (" + e + "x" + t + ").")
                                }
                            }
                            if (h("registerListenersAndPositionElements invoked."), l(n)) {
                                l(n).onRendered = function() {
                                    if (h("startanimation triggered."), g(n)) h("Ignoring since element is still unrendered...");
                                    else {
                                        h("Element rendered.");
                                        var e = o(n),
                                            t = r(n);
                                        0 !== e.scrollLeft && 0 !== e.scrollTop && 0 !== t.scrollLeft && 0 !== t.scrollTop || (h("Scrollbars out of sync. Updating detector elements..."), c(f))
                                    }
                                }, l(n).onExpand = p, l(n).onShrink = p;
                                var v = l(n).style;
                                t(n, v.width, v.height)
                            } else h("Aborting because element has been uninstalled")
                        }

                        function k() {
                            if (h("finalizeDomMutation invoked."), l(n)) {
                                var e = l(n).style;
                                m(n, e.width, e.height), E(n, e.width, e.height)
                            } else h("Aborting because element has been uninstalled")
                        }

                        function H() {
                            f(n)
                        }

                        function L() {
                            h("Installing..."), l(n).listeners = [],
                                function() {
                                    var e = p();
                                    l(n).startSize = {
                                        width: e.width,
                                        height: e.height
                                    }, h("Element start size", l(n).startSize)
                                }(), s.add(0, v), s.add(1, z), s.add(2, A), s.add(3, k), s.add(4, H)
                        }
                        f || (f = n, n = e, e = null), e = e || {}, h("Making detectable..."),
                            function(e) {
                                return ! function(e) {
                                    return e === e.ownerDocument.body || e.ownerDocument.body.contains(e)
                                }(e) || null === getComputedStyle(e)
                            }(n) ? (h("Element is detached"), S(), h("Waiting until element is attached..."), l(n).onRendered = function() {
                                h("Element is now attached"), L()
                            }) : L()
                    },
                    addListener: function(e, t) {
                        if (!l(e).listeners.push) throw new Error("Cannot add listener to an element that is not detectable.");
                        l(e).listeners.push(t)
                    },
                    uninstall: function(e) {
                        var t = l(e);
                        t && (t.onExpandScroll && n(o(e), "scroll", t.onExpandScroll), t.onShrinkScroll && n(r(e), "scroll", t.onShrinkScroll), t.onAnimationStart && n(t.container, "animationstart", t.onAnimationStart), t.container && e.removeChild(t.container))
                    }
                }
            }
        }, {
            "../collection-utils": 4
        }],
        7: [function(e, t, n) {
            "use strict";

            function i(e) {
                return Array.isArray(e) || void 0 !== e.length
            }

            function o(e) {
                if (Array.isArray(e)) return e;
                var t = [];
                return s(e, function(e) {
                    t.push(e)
                }), t
            }

            function r(e) {
                return e && 1 === e.nodeType
            }

            function a(e, t, n) {
                var i = e[t];
                return void 0 !== i && null !== i || void 0 === n ? i : n
            }
            var s = e("./collection-utils").forEach,
                l = e("./element-utils"),
                d = e("./listener-handler"),
                c = e("./id-generator"),
                u = e("./id-handler"),
                f = e("./reporter"),
                h = e("./browser-detector"),
                g = e("batch-processor"),
                p = e("./state-handler"),
                v = e("./detection-strategy/object.js"),
                m = e("./detection-strategy/scroll.js");
            t.exports = function(e) {
                var t;
                if ((e = e || {}).idHandler) t = {
                    get: function(t) {
                        return e.idHandler.get(t, !0)
                    },
                    set: e.idHandler.set
                };
                else {
                    var n = c(),
                        b = u({
                            idGenerator: n,
                            stateHandler: p
                        });
                    t = b
                }
                var y = e.reporter;
                if (!y) {
                    y = f(!1 === y)
                }
                var w = a(e, "batchProcessor", g({
                        reporter: y
                    })),
                    x = {};
                x.callOnAdd = !!a(e, "callOnAdd", !0), x.debug = !!a(e, "debug", !1);
                var E, S = d(t),
                    z = l({
                        stateHandler: p
                    }),
                    A = a(e, "strategy", "object"),
                    k = {
                        reporter: y,
                        batchProcessor: w,
                        stateHandler: p,
                        idHandler: t
                    };
                if ("scroll" === A && (h.isLegacyOpera() ? (y.warn("Scroll strategy is not supported on legacy Opera. Changing to object strategy."), A = "object") : h.isIE(9) && (y.warn("Scroll strategy is not supported on IE9. Changing to object strategy."), A = "object")), "scroll" === A) E = m(k);
                else {
                    if ("object" !== A) throw new Error("Invalid strategy name: " + A);
                    E = v(k)
                }
                var H = {};
                return {
                    listenTo: function(e, n, l) {
                        function d(e) {
                            var t = S.get(e);
                            s(t, function(t) {
                                t(e)
                            })
                        }

                        function c(e, t, n) {
                            S.add(t, n), e && n(t)
                        }
                        if (l || (l = n, n = e, e = {}), !n) throw new Error("At least one element required.");
                        if (!l) throw new Error("Listener required.");
                        if (r(n)) n = [n];
                        else {
                            if (!i(n)) return y.error("Invalid arguments. Must be a DOM element or a collection of DOM elements.");
                            n = o(n)
                        }
                        var u = 0,
                            f = a(e, "callOnAdd", x.callOnAdd),
                            h = a(e, "onReady", function() {}),
                            g = a(e, "debug", x.debug);
                        s(n, function(e) {
                            p.getState(e) || (p.initState(e), t.set(e));
                            var i = t.get(e);
                            if (g && y.log("Attaching listener to element", i, e), !z.isDetectable(e)) return g && y.log(i, "Not detectable."), z.isBusy(e) ? (g && y.log(i, "System busy making it detectable"), c(f, e, l), H[i] = H[i] || [], void H[i].push(function() {
                                ++u === n.length && h()
                            })) : (g && y.log(i, "Making detectable..."), z.markBusy(e, !0), E.makeDetectable({
                                debug: g
                            }, e, function(e) {
                                if (g && y.log(i, "onElementDetectable"), p.getState(e)) {
                                    z.markAsDetectable(e), z.markBusy(e, !1), E.addListener(e, d), c(f, e, l);
                                    var t = p.getState(e);
                                    if (t && t.startSize) {
                                        var o = e.offsetWidth,
                                            r = e.offsetHeight;
                                        t.startSize.width === o && t.startSize.height === r || d(e)
                                    }
                                    H[i] && s(H[i], function(e) {
                                        e()
                                    })
                                } else g && y.log(i, "Element uninstalled before being detectable.");
                                delete H[i], ++u === n.length && h()
                            }));
                            g && y.log(i, "Already detecable, adding listener."), c(f, e, l), u++
                        }), u === n.length && h()
                    },
                    removeListener: S.removeListener,
                    removeAllListeners: S.removeAllListeners,
                    uninstall: function(e) {
                        if (!e) return y.error("At least one element is required.");
                        if (r(e)) e = [e];
                        else {
                            if (!i(e)) return y.error("Invalid arguments. Must be a DOM element or a collection of DOM elements.");
                            e = o(e)
                        }
                        s(e, function(e) {
                            S.removeAllListeners(e), E.uninstall(e), p.cleanState(e)
                        })
                    }
                }
            }
        }, {
            "./browser-detector": 3,
            "./collection-utils": 4,
            "./detection-strategy/object.js": 5,
            "./detection-strategy/scroll.js": 6,
            "./element-utils": 8,
            "./id-generator": 9,
            "./id-handler": 10,
            "./listener-handler": 11,
            "./reporter": 12,
            "./state-handler": 13,
            "batch-processor": 1
        }],
        8: [function(e, t, n) {
            "use strict";
            t.exports = function(e) {
                var t = e.stateHandler.getState;
                return {
                    isDetectable: function(e) {
                        var n = t(e);
                        return n && !!n.isDetectable
                    },
                    markAsDetectable: function(e) {
                        t(e).isDetectable = !0
                    },
                    isBusy: function(e) {
                        return !!t(e).busy
                    },
                    markBusy: function(e, n) {
                        t(e).busy = !!n
                    }
                }
            }
        }, {}],
        9: [function(e, t, n) {
            "use strict";
            t.exports = function() {
                var e = 1;
                return {
                    generate: function() {
                        return e++
                    }
                }
            }
        }, {}],
        10: [function(e, t, n) {
            "use strict";
            t.exports = function(e) {
                var t = e.idGenerator,
                    n = e.stateHandler.getState;
                return {
                    get: function(e) {
                        var t = n(e);
                        return t && void 0 !== t.id ? t.id : null
                    },
                    set: function(e) {
                        var i = n(e);
                        if (!i) throw new Error("setId required the element to have a resize detection state.");
                        var o = t.generate();
                        return i.id = o, o
                    }
                }
            }
        }, {}],
        11: [function(e, t, n) {
            "use strict";
            t.exports = function(e) {
                function t(t) {
                    var i = e.get(t);
                    return void 0 === i ? [] : n[i] || []
                }
                var n = {};
                return {
                    get: t,
                    add: function(t, i) {
                        var o = e.get(t);
                        n[o] || (n[o] = []), n[o].push(i)
                    },
                    removeListener: function(e, n) {
                        for (var i = t(e), o = 0, r = i.length; o < r; ++o)
                            if (i[o] === n) {
                                i.splice(o, 1);
                                break
                            }
                    },
                    removeAllListeners: function(e) {
                        var n = t(e);
                        n && (n.length = 0)
                    }
                }
            }
        }, {}],
        12: [function(e, t, n) {
            "use strict";
            t.exports = function(e) {
                function t() {}
                var n = {
                    log: t,
                    warn: t,
                    error: t
                };
                if (!e && window.console) {
                    var i = function(e, t) {
                        e[t] = function() {
                            var e = console[t];
                            if (e.apply) e.apply(console, arguments);
                            else
                                for (var n = 0; n < arguments.length; n++) e(arguments[n])
                        }
                    };
                    i(n, "log"), i(n, "warn"), i(n, "error")
                }
                return n
            }
        }, {}],
        13: [function(e, t, n) {
            "use strict";

            function i(e) {
                return e[o]
            }
            var o = "_erd";
            t.exports = {
                initState: function(e) {
                    return e[o] = {}, i(e)
                },
                getState: i,
                cleanState: function(e) {
                    delete e[o]
                }
            }
        }, {}]
    }, {}, [7])(7)
});