var searchList = {
    google: {
        url: "https://www.google.com/search?q=",
        img: 'images/google.png'
    },
    yahoo: {
        url: "https://search.yahoo.com/search?isource=infinity&iname=yahoo&itype=web&p=",
        img: 'images/yahoo.png'
    },
    baidu: {
        url: "https://www.baidu.com/s?wd=",
        img: 'images/baidu.png'
    },
    bing: {
        url: "https://bing.com/search?isource=infinity&iname=bing&itype=web&q=",
        img: 'images/bing.png'
    },
    yandex: {
        url: "https://yandex.com/search/?isource=infinity&itype=web&iname=yandex&text=",
        img: 'images/yandex.png'
    },
    duckduckgo: {
        url: "https://duckduckgo.com/?isource=infinity&iname=duckduckgo&itype=web&q=",
        img: 'images/duckduckgo.png'
    },
    360: {
        url: "https://www.so.com/s?src=lm&ls=sm2054017&lm_extend=ctype:4&q=",
        img: 'images/360.png'
    },
    sogou: {
        url: "https://sogou.com/web?isource=infinity&iname=sogou&itype=web&_asf=infinitynewtab.com&query=",
        img: 'images/sogou.png'
    }
}
var i18n = {
    get: function(val) {
        if (isZhLanguage())
		{
            return this[val].zh;
        }
		else
		{
            return this[val].en;
        }
    },
    Copysuccessfully: {
        zh: '复制成功',
        en: 'Copy successfully'
    },
    Copyfailed: {
        zh: '复制失败',
        en: 'Copy failed'
    },
    Addtomainscreen: {
        zh: '添加到主屏幕',
        en: 'Add to main screen',
    },
    Clicktoshare: {
        zh: '点击分享',
        en: 'Click to share',
    },
    Safariopens: {
        zh: 'Safari浏览器打开',
        en: 'Safari opens'
    },
    pleaseuse: {
        zh: '请使用',
        en: 'please use',
    },
    Clickcopy: {
        zh: '点击复制',
        en: 'Click copy'
    },
    Addtothedesktop: {
        zh: '添加到桌面',
        en: 'Add to the desktop'
    },
    donotshowagain: {
        zh: '不再显示',
        en: 'do not show again'
    }
}
//初始化数据
try
{
    initData();

} catch (e) {
    console(e);
}


// 判断浏览器语言 是否是中文
function isZhLanguage() {
    var language = navigator.language || navigator.browserLanguage;
    if (language.indexOf('zh-CN') > -1)
	{
        return true;
    }
	else
	{
        return false;
    }

}
//重新选择默认搜索
function resetSearch(defaultSearchType) {
    var searchImg = searchList[defaultSearchType].img;
    $("#currentSearchLogo").attr("src", searchImg)
}
//初始化数据方法
function initData() {
var defaultSearchType = 'baidu';
    var defaultData=null;
    
    var url = window.location.href;
    if (url.indexOf('?') === 1)
	{
            defaultSearchType = 'baidu'; //中文
            // 默认中文数据
            defaultData = {
                "status": 200,
                "desc": "OK",
                "data": [
					{
						"uid": "60e546111669c1d829f962c8831a0926",
						"name": "Youtube",
						"url": "https://youtube.com",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/37d396f9975e494b10ac8696d64ebb2a.png",
						"imageType": "image",
						"id": "b4e30f17-546f-4961-a3f3-d3857d00f045",
						"updateTime": 0,
						"bgColor": "transparent",
						"isCustom": false
					},
					{
						"id": "09eedbd5-ab94-494d-b8d0-ad6497d2d65c",
						"uid": "7c3fa3a53b0c637bf44b7d05efefce83",
						"imageType": "image",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/7c3fa3a53b0c637bf44b7d05efefce83.png",
						"url": "https://weibo.com/",
						"name": "微博",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734920524
					},
					{
						"id": "1a1e3cb4-64d6-4e10-83a2-b20cce9fe6da",
						"uid": "7217a2ae99c3fd510f2f25c4c4866065",
						"imageType": "image",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/7217a2ae99c3fd510f2f25c4c4866065.png",
						"url": "http://www.instagram.com",
						"name": "Instagram",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734725779
					},
					{
						"id": "01e03109-5473-4a37-8b7e-f6a4bb3eefe2",
						"uid": "92ed240c60c284adc2f2e411205176dc",
						"imageType": "image",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/4277652ad8ce6b2d8377b092ad31507c.png",
						"url": "https://www.facebook.com",
						"name": "Facebook",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734957359
					},
					{
						"id": "2568325e-b988-44d1-a925-419e3cef7a7d",
						"uid": "3723b5edaba6c5b802c823bc4da2d043",
						"imageType": "image",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/3723b5edaba6c5b802c823bc4da2d043.png",
						"url": "https://www.twitter.com",
						"name": "Twitter",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734233418
					},
					{
						"id": "bf3bb9d9-ce85-43ec-91df-6652d4842f10",
						"uid": "3cd74e939b1011a6d99ea02b7404111d",
						"imageType": "image",
						"src": "https://infinitypro-img.infinitynewtab.com/custom-icon/8001ckrvk396xldwp29mum4xw6xj3e.png",
						"url": "https://mail.yandex.ru/",
						"name": "Yandex Mail",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734620460
					},
					{
						"id": "5fb44b09-3ca4-46d7-ba99-f6bdd94bf6b4",
						"uid": "d0143f95f23f03241a135feff76f2290",
						"imageType": "image",
						"src": "https://infinitypro-img.infinitynewtab.com/custom-icon/9001c1kg4bskjcsfw0p69skv40ca8i.png",
						"url": "https://mail.qq.com",
						"name": "QQ邮箱",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734358584
					},
					{
						"id": "cebd6962-e10b-409f-aca1-06399256e7f6",
						"uid": "82b36c76a76d32589ab948eabbfce642",
						"imageType": "image",
						"src": "https://infinityicon.infinitynewtab.com/user-share-icon/82b36c76a76d32589ab948eabbfce642.png",
						"url": "https://outlook.com",
						"name": "Outlook",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734324221
					},
					{
						"id": "eea026ca-a512-4cce-b6f5-c93fb58b628b",
						"uid": "17dbcad88a0163ed4b99893c9f74a492",
						"imageType": "image",
						"src": "https://infinitypro-img.infinitynewtab.com/custom-icon/9001c1s24m3utlfxbm8y4daypq4nr6.png",
						"url": "https://mail.google.com/mail/u/0/",
						"name": "Gmail",
						"isCustom": false,
						"bgColor": "transparent",
						"tempBgColor": "transparent",
						"updateTime": 1585734174423
					}],
                "backupTime": 1515556313462
            }
    }
    //从localstorage中获取数据
    var storageData = getStorage('defaultData');
    if (!storageData)
	{ //数据为空
        console.error("数据为空");

        if (defaultData)
		{

            dellWithShowIconData(defaultData);
        }
		else
		{
            console.log('kdkdk');
            getNewData();
        }
        // dellWithShowIconData(defaultData)
    }
    if (storageData)
	{
        dellWithShowIconData(storageData);
    }

    //从localstorage中获取默认搜索
    var localDefaultSearchType = getStorage('defaultSearchType');
    if (!localDefaultSearchType)
	{
        resetSearch(defaultSearchType)
        //存储默认搜索
        setStorage('defaultSearchType', defaultSearchType);
    }
    if (localDefaultSearchType)
	{
        resetSearch(localDefaultSearchType)
    }



}




function reloadPageInit() {
    var ulBox = $("#ul-box");
    // var searchInput = $("#searchInput");

    if (ulBox.css("display") == 'none')
	{
        ulBox.show();

    }
    // if (searchInput.length !== 0) {
    //     searchInput.val('');
    // }
    if ($("#search-suggestion ul").length !== 0)
	{
        $("#search-suggestion ul").hide();
    }

}





// 浏览器判断
var browser = {
    versions: function() {
        var u = navigator.userAgent,
            app = navigator.appVersion;
        return {
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
            iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
            weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
            qq: u.match(/\sQQ/i) !== null, //是否QQ
            Safari: u.indexOf("Safari") > -1 && u.indexOf("Chrome") < 1 && u.indexOf("Version") > -1
        };
    }(),
    language: (navigator.browserLanguage || navigator.language).toLowerCase()
}
$(function() {
	  if (browser.versions.mobile)
	  {

		  FastClick.attach(document.body); //是移动端的时候增加fastclick支持

		  var remindStr = "";
		  console.info('是否是Safari', navigator.userAgent, /iP(ad|hone|od).+Version\/[\d\.]+.*Safari/i.test(navigator.userAgent), !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/))
		  if (browser.versions.ios)
		  { //判断为iOS或者iPad的情况


			  if (browser.versions.Safari)
			  { //为Safari浏览器的时候

				  if (getStorage("isShowRemind") === "y")
				  {
					  return;
				  }
				  remindStr += '<div id=\"remind-to-home\"><div class=\"remind-to-home-box\"><img src=\"img/icon-add-to-screen.png\" ><span id=\"add-to-screen\">' + i18n.get("Addtothedesktop") + '</span><button id=\"no-show\">' + i18n.get("donotshowagain") + '</button></div><div class=\"triangle-down\"></div> </div>';
				  $("#remindHomeTopBox").html(remindStr);
			  }
			  else if (browser.versions.weixin || browser.versions.qq)
			  { //微信或者qq浏览器

				  remindStr += '<div id=\"remindBrower\">\
                    <div id=\"arrowsWeixin\">\
                    <img src=\"img/icon-arrows-right.svg\" >\
                    </div>\
                    <div id=\"remindFlow\">\
                <div class=\"remind-flow1\">\
                    <img src=\"img/icon-safari.svg\" >\
                    <span>\
                    <p class=\"remind-font firstp\">' + i18n.get("pleaseuse") + '</p>\
                    <p class=\"remind-font\">' + i18n.get("Safariopens") + '</p>\
                </span>\
                </div>\
                <div class=\"renmind-arrows\">\
                    <img src=\"img/icon-next.svg\" >\
                </div>\
                <div>\
                    <img src=\"img/icon-Safari – Share.svg\" >\
                    <p class=\"remind-font remind-title\">' + i18n.get("Clicktoshare") + '</p>\
                </div>\
                <div class=\"renmind-arrows\">\
                    <img src=\"img/icon-next.svg\" >\
                </div>\
                <div>\
                    <img src=\"img/icon-safari-add-homescreen.svg\" >\
                    <p class=\"remind-font remind-title\">' + i18n.get("Addtomainscreen") + '</p>\
                </div>\
                 </div>\
                </div>'
				  $("#remindBrowerTopBox").html(remindStr);


			  }
			  else
			  { //iOS其它浏览器
				  var isremind = getStorage("isremind");
				  if (isremind === 'y')
				  {
					  return;
				  }
				  remindStr += '<div id=\"remindBrower\">\
                    <div id=\"arrowsWeixin\">\
                    </div>\
                    <div id=\"remindFlow\">\
                    <div class=\"remind-flow1\">\
                    <img src=\"img/icon-safari.svg\" >\
                    <span>\
                    <p class=\"remind-font firstp\">' + i18n.get("pleaseuse") + '</p>\
                    <p class=\"remind-font\">' + i18n.get("Safariopens") + '</p>\
                    </span>\
                    </div>\
                    <div class=\"renmind-arrows\">\
                    <img src=\"img/icon-next.svg\" >\
                    </div>\
                    <div>\
                    <img src=\"img/icon-Safari – Share.svg\" >\
                    <p class=\"remind-font remind-title\">' + i18n.get("Clicktoshare") + '</p>\
                    </div>\
                    <div class=\"renmind-arrows\">\
                    <img src=\"img/icon-next.svg\" >\
                    </div>\
                    <div class=\"close-button-remind\"></div>\
                <div>\
                    <img src=\"img/icon-safari-add-homescreen.svg\" >\
                    <p class=\"remind-font remind-title\">' + i18n.get("Addtomainscreen") + '</p>\
                </div>\
            </div>\
            <div id=\"content-url\">\
                <div class=\"remind-font1\" id=\"UrlCopy\">' + window.location.href + '</div>\
                <button class=\"remind-font1\" id=\"copyUrlBtn\" data-clipboard-target=\"#UrlCopy\">' + i18n.get("Clickcopy") + '</button>\
            </div>\
        </div>'
				  $("#remindBrowerTopBox").html(remindStr);
			  }
		  }
		  else if (browser.versions.android)
		  {
			  if (getStorage("isShowRemind") === "y")
			  {
				  return;
			  }

			  remindStr += '<div id=\"remind-to-home\"><div class=\"remind-to-home-box\"><img src=\"img/icon-add-to-screen.png\" ><span id=\"add-to-screen\">' + i18n.get("Addtothedesktop") + '</span><button id=\"no-show\">' + i18n.get("donotshowagain") + '</button></div> </div>';
			  $("#remindHomeTopBox").html(remindStr);
		  }
	  }


  });

function getParameters(name, url) {
    if (!url) url = location.href;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(url);
    return results == null ? null : results[1];
}

// 请求图标数据
// 从图标中获取参数方法
function getNewData() {
    var currentUrl = "m.infinitynewtab.com?OaEdkj";
    var getDataUrl = '';
    // var uid = getParameters('uid', currentUrl) || "292fc1c19e4b62de7a947bc4e5625ccb";
    // var secret = getParameters('secret', currentUrl) || "f8645b46d1b1529228fc7d211c408230";
    var uid = getParameters('uid', currentUrl);
    var secret = getParameters('secret', currentUrl);

    if ((!uid) && (!secret))
	{
        var mobileArray = currentUrl.split('?');
        if (mobileArray.length === 2 && mobileArray[1].length === 6)
		{
            getDataUrl = 'https://infinity-api.infinitynewtab.com/c/' + mobileArray[1].replace('=', '');
        }
		else
		{
            return;
        }

    }
    if (uid && secret)
	{
        getDataUrl = "https://infinity-api.infinitynewtab.com/c/0?uid=" + uid + "&secret=" + secret;
    }

    $.get(getDataUrl, function(response, status, xhr) {
			  if (status == "success" && response.status === 200)
			  {

				  var backupTime = response.backupTime;
				  var localBackupTime = 0;
				  var defaultData = getStorage('defaultData')
				  if (defaultData)
				  {
					  localBackupTime = defaultData.backupTime
					  if (localBackupTime !== backupTime)
					  {

						  dellWithShowIconData(response)
						  setStorage('defaultData', response)
					  }
				  }
				  else
				  {
					  dellWithShowIconData(response)
					  setStorage('defaultData', response)
				  }



			  }

		  })
}

function getFolderUrl(folderId) {
    var currentUrl = window.location.href;

    var uid = getParameters('uid', currentUrl);
    var secret = getParameters('secret', currentUrl);

    var mobileId = null;
    if (!uid || !secret)
	{
        var mobileArray = currentUrl.split('?');

        if (mobileArray.length === 2 && mobileArray[1].length === 6)
		{
            mobileId = mobileArray[1].replace('=', '');
        }
    }
//var a="/storage/sdcard1/new";
    var url = location.protocol + '//' + location.host + '/folder.html?';
//var url = location.protocol + '//' + a + '/folder.html?';

    var search = [
        'folderId=' + folderId
    ];
    if (uid && secret)
	{
        search.push(
            'uid=' + uid + '&secret=' + secret
        );
    }

    if (mobileId)
	{
        search.push(
            'mobileId=' + mobileId
        );
    }

    return url + search.join('&');
}

function dellWithShowIconData(data) {
    data = data.data;

    var str = '';
    // data=data.slice(0,20)
    var j = data.length;
    var dlen = j;
    while (j--)
	{
        var url = data[j].url;
        var name = data[j].name;
        var src = data[j].src;

        switch (data[j].imageType)
		{
            case 'color':
                var bgcolor = data[j].bgColor;
                str += '<li>' + '<a href="' + url + '"' + 'target=\"_self\"' + '>' + '<div class=\"icon-img-box\" style=\"background:' + bgcolor + ';\"' + ' >' + name + '</div>' + '<p class="' + 'overflow-ellips' + '">' + name + '</p></a></li>';
                break;
            case 'folder':
                url = getFolderUrl(data[j].id);
                str += '<li>' + '<a href="' + url + '"' + 'target=\"_self\"' + '>' + '<div class=\"icon-img-box folder-icon-img-box\">' + '<img src="images/folder.png"></div>' + '<p class="' + 'overflow-ellips' + '">' + name + '</p></a></li>';
                break;
            default:
                str += '<li>' + '<a href="' + url + '"' + 'target=\"_self\"' + '>' + '<div class=\"icon-img-box\">' + '<img src=\"' + src + '"></div>' + '<p class="' + 'overflow-ellips' + '">' + name + '</p></a></li>';
                break;
        }
    }

    str += '<li id=\"fakeitem\"></li>'

    document.getElementById("list-item").innerHTML = str;
    calcateIconLayOut(dlen);
    getNewData();

}

// 计算放几个图标摆放布局
function calcateIconLayOut(j) {


    var erd = elementResizeDetectorMaker();

    var erdUltraFast = elementResizeDetectorMaker({
													  strategy: 'scroll'
												  });

    var totalCount = j; //计算加载图标的总个数
    console.log('图标总个数', totalCount)
    var wrapper = document.getElementById('ul-box');
    var container = document.getElementById('list-item');
    var fakeItem = document.getElementById('fakeitem');
    console.log('fakeitem-----', fakeItem)
    var appended = false;
    var perWidth = (document.body.clientWidth / 100).toFixed(2)
    console.log('fakeitem', fakeItem)
    // fakeItem.classList.add('fake-item');

    layloutReset(totalCount, container, fakeItem, appended)
    erd.listenTo(
        wrapper,
        function(el) {
            layloutReset(totalCount, container, fakeItem, appended)

        }
    );

}
//计算布局
function layloutReset(totalCount, container, fakeItem, appended) {

    var width = container.offsetWidth;
    var perWidth = (document.body.clientWidth / 100) * 2.4.toFixed(3);
    var itemWidth = 45 + perWidth * 2;
    console.log('每个item的宽度', itemWidth, perWidth)
    // 一行能最多摆放的数量
    var maxCountInRow = Math.floor(width / itemWidth); //一行摆放最大的数量
    console.log("最大摆放数量", maxCountInRow)

    // 间隔尺寸

    var spaceSize = ((width - (maxCountInRow) * itemWidth) / (maxCountInRow - 1)).toFixed(3) //间隔尺寸
    console.log('间隔尺寸', spaceSize)

    // 最后一行摆放的数量
    var minCountInRow = totalCount % maxCountInRow; //最后一行摆放数量
    console.log('最后一行摆放的数量', minCountInRow)

    if (minCountInRow > 0)
	{
        // 需要fake item
        // if (!appended) {
        //     container.appendChild(fakeItem);
        //     appended = true;
        // }
        // 计算fakeItem的体积
        var itemSize = maxCountInRow - minCountInRow;
        console.log('宽度，剩下摆放数量', (itemSize * itemWidth + (itemSize - 1) * spaceSize).toFixed(2) + 'px', itemSize)
        var fakeItemWidth = (itemSize * itemWidth + (itemSize - 1) * spaceSize).toFixed(2);
        // fakeItem.style.width = fakeItemWidth + 'px';

        console.log('fakeItem########', fakeItem)
        fakeItem.style.cssText = "display:block;visibility: hidden;height: 0;padding:0;margin:0;width:" + fakeItemWidth + "px;";
    }
	else
	{
        // 不需要fake item
        console.log("不需要fakeitem", fakeItem)
        fakeItem.style.cssText = "display:none;"

    }

}

// 搜索切换
//设定默认搜索
var defaultSearchType = 'google';
var language = navigator.language || navigator.browserLanguage;
if (language.indexOf('zh') > -1)
{
    defaultSearchType = 'baidu'; //中文
}
else
{
    defaultSearchType = "google"; //英文
}


//点击搜索
$("#searchSubmit").on("submit", function(ev) {

						  var searchContent = $("#searchInput").val();

						  openSearchResult(searchContent)
						  ev.preventDefault()
					  })

function handleOutboundLinkClicks(defaultSearchType, val) {
    gtag('event', 'search', {
			 'event_action': defaultSearchType,
			 'event_label': val
		 });
}

function openSearchResult(val) {
    var defaultSearchType = getStorage("defaultSearchType")
    var searchOpenUrl = searchList[defaultSearchType].url + val;
    //     if(defaultSearchType.indexOf('baidu')!=-1){
    //     searchOpenUrl=searchOpenUrl+'&tn=99006304_7_oem_dg'
    // }
    handleOutboundLinkClicks(defaultSearchType, val)
    if ($("#search-suggestion ul").length !== 0)
	{
        $("#search-suggestion ul").hide();
        $("#ul-box").show();
    }
    window.location.href = searchOpenUrl;




}

function Arrayprocess(arr) {
    var newarr = [];
    for (var i = 0, len = arr.length; i < len; i++)
	{
        newarr.push(arr[i].word)
    }
    return newarr
}
//搜索切换
$("#search-list").on("click", "li", function() {

						 var search_type = $(this).data("search_type");
						 var search_img = $(this).children("img").attr('src')
						 resetSearch(search_type)

						 $("#search-list").hide();
						 $("#ul-box").show();
						 setStorage('defaultSearchType', search_type)

					 })
// 展示搜索选项
$(".search-logo").on("click", function() {
						 var searchListDom = $("#search-list");
						 if (searchListDom.css('display') == "none")
						 {
							 $("#search-list").show();
							 $("#ul-box").hide();

						 }
						 else
						 {
							 $("#search-list").hide();
							 $("#ul-box").show();
						 }
					 })


// 搜索提示
$("#searchInput").on("input", function() {

						 var valValue = $(this).val();
						 if (valValue.length === 0)
						 {
							 $("#search-suggestion").html("");
							 $("#ul-box").show();
							 return;
						 }

						 var getSuggestionUrl = "https://sug.so.360.cn/suggest?callback=?&encodein=utf-8&encodeout=utf-8&format=json&fields=word&word=" + valValue;
						 var isZhlang = isZhLanguage();
						 if (!isZhlang)
						 {
							 getSuggestionUrl = "https://suggestqueries.google.com/complete/search?output=chrome&hl=" + navigator.language + "&q=" + valValue + "&hl=" + navigator.language + "&infinityTime=1515986391815";
						 }
						 console.log('getSuggestionUrl', getSuggestionUrl)
						 $.ajax({
									url: getSuggestionUrl,
									dataType: 'jsonp',
									success: function(data) {




										var suggestionDataAarry = [];
										if (!isZhlang)
										{
											suggestionDataAarry = data[1].slice(0, 10);
										}
										if (isZhlang)
										{
											suggestionDataAarry = Arrayprocess(data.result);
											console.log(Arrayprocess(data.result))
										}
										var str = "";
										var len = suggestionDataAarry.length;
										if (len != 0)
										{
											str += "<ul>"
											while (len--)
											{
												str += '<li>' + suggestionDataAarry[len] + '</li>';
											}
											console.log(str)
											str += "</ul>"
											$("#search-suggestion").html(str);
											$("#ul-box").hide();
										}
										else
										{
											str += "</ul>"
											$("#search-suggestion").html(str);
											$("#ul-box").show();
										}
									},
									error: function(e) {
										console.error('请求数据接口出错', e)
									}
								})

					 })

// 点击搜索提示
$("#search-suggestion").on("click", "li", function() {
							   openSearchResult($(this).text())
						   })


//接口localstorage存储

function isSuportLocalStorage() {
    if (window.localStorage)
	{ //支持localstorage
        return true
    }
	else
	{
        return false
    }
}


function setStorage(key, val) {
    var valType = Object.prototype.toString.call(val);
    if (valType === "[object Array]" || valType === "[object Object]")
	{ //数组或者对象
        val = JSON.stringify(val);
    }
    localStorage.setItem(key, val)
    if ((!localStorage[val]) && val.length < 50)
	{
        Cookies.set(key, val, {
						expires: 37
					});
    }

}

function getStorage(key) {
    try
	{

        var val = localStorage.getItem(key)
        if (!val)
		{
            return Cookies.get(key);
        }
		else
		{
            return JSON.parse(val);
        }


    } catch (e) {
        return val
    }

}



window.addEventListener('pageshow', function(event) {

							if (event.persisted)
							{

								reloadPageInit()
								// window.location.reload()
							}
						});
// window.addEventListener('beforeunload', function(event) {
//     reloadPageInit();
// });
var matches = function(el, selector) {
    return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector || el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
};
var t = matches(document.getElementById("search-list"), "#search-list");
$(document).on("click", function(e) {
				   var _con = $('#search-list'); // 设置目标区域

				   if ($(event.target).closest(_con).length === 0 && _con.has(e.target).length === 0)
				   { // Mark
					   // console.log('点击弹出外面')

					   if ($(".search-logo").has(event.target).length === 1 || event.target.className == 'search-logo')
					   {


						   return;
					   }
					   if (_con.css("display") !== "none")
					   {

						   _con.hide();
					   }
					   if ($("#ul-box").css("display") == "none")
					   {
						   $("#ul-box").show();
					   }

					   // if($("#search-suggestion").has(event.target).length!==1){
					   //     console.log('搜索建议',event.target.id,event.target.id!='searchInput')

					   //     if(event.target.id!='searchInput'&&$("#search-suggestion ul li").length!=0){
					   //         $("#search-suggestion ul").html('')
					   //         console.log("搜索建议还在显示哦哦")
					   //     }
					   //     else{

					   //         return;
					   //     }
					   // }



				   }
				   else
				   {

					   return;


				   }
			   });

function temp(msg, duration) {
    var el = document.createElement("div");
    el.setAttribute("style", "position:fixed;z-index:999;top:0;background-color:#fff;width:100%;left:0;text-align:center;height:40px;line-height:40px;color:#a5a5a5; ");
    el.innerHTML = msg;
    setTimeout(function() {
				   el.parentNode.removeChild(el);
			   }, duration);
    document.body.appendChild(el);
}

//复制文字
if (Clipboard.isSupported())
{ //当支持的时候
    var clipboard = new Clipboard('#copyUrlBtn');

    clipboard.on('success', function(e) {
					 e.clearSelection();
					 tempAlert(i18n.get("Copysuccessfully"), 1500)
				 });

    clipboard.on('error', function(e) {
					 tempAlert(i18n.get("Copyfailed"), 1500)

				 });
}
// 关闭不再提醒
$(document).on("click", ".close-button-remind", function() {
				   $("#remindBrower").hide();
				   setStorage('isremind', 'y')
			   })
//文字不再显示
$(document).on("click", "#no-show", function() {
				   setStorage("isShowRemind", 'y')
				   $("#remind-to-home").remove();
			   })
